const mongoose= require('mongoose'); //import  the module mongoose with require built in function of javascript
mongoose.connect("mongodb://127.0.0.1:27017/test");// conecting the module
const  student2Schema = new mongoose.Schema({
    'name':String,
    'id':Number,
    'age':Number,
    'address':String,
});
//  const insert =async ()=>{
//     const Student=mongoose.model('students',studentSchema);
//     let data= new Student({
//         'name':'A',
     //      'id':'34576767'
//         'age':22,
//         'address':'mumbai',
//     });

//     let result=await data.save();
//     console.log(result);
//  }
//  insert();
const insert=async ()=>{
    const Student2=mongoose.model('student2',student2Schema);

let data1= new Student2({
           'name':'jeery',
               'id':'34537867',
            'age':'57',
            'address':'vasai',
     });
     let res=await data1.save();
    console.log(res);
}
insert();
//  const update=async ()=>{
//      let Student=mongoose.model('students',studentSchema);
//      let data= await Student.updateOne({'name':'B'},{$set:{'name':'C'}
//  });
//      console.log(data);

//  }
//  update();
//  const deleted= async ()=>{
//     let Student=mongoose.model('students',studentSchema);
//     let data= await Student.deleteOne({'name':'C'});
//     console.log(data);
// }
// deleted();
