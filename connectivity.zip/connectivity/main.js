const mongodb=require('mongodb');

const url="mongodb://127.0.0.1:27017/";
const db1='test';


const client= new mongodb.MongoClient(url);

async function insert(){
    let result=await client.connect();
    let db= result.db(db1);
    let collections=db.collection('users');
    collections.insertOne({'name':'tom'});
  
}
insert();
async function show(){
    let result=await client.connect();
    let db= result.db(db1);
    let collections=db.collection('users');
    let data=await collections.find({}).toArray();
    console.log(data);
}
show();
